package com.natural;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TinyOutageApplication {

	public static void main(String[] args) {
		SpringApplication.run(TinyOutageApplication.class, args);
	}

}
